import fs from 'node:fs';
const read=name=>fs.readFileSync(new URL('../server/'+name,import.meta.url),'utf8');
fs.writeFileSync(new URL('../server/pages.mjs',import.meta.url),'export const DASHBOARD_HTML='+JSON.stringify(read('dashboard.html'))+';\nexport const LABEL_HTML='+JSON.stringify(read('labels.html'))+';\n');
