(function(root){'use strict';
const clean=value=>String(value??'').replace(/[\u200b-\u200d\ufeff]/g,'').replace(/\s+/g,' ').trim(),key=value=>clean(value).toLowerCase().replace(/[^\p{L}\p{N}]/gu,''),escape=value=>value.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
const aliases={
 'Name':['name','customer name','customer','full name','receiver name','consignee','recipient','नाम','ग्राहक का नाम'],
 'Mobile':['mobile','mob','mo.no','mo no','mobile no','mobile number','mob no','phone','phone no','phone number','contact','contact no','contact number','telephone','मोबाइल','मोबाइल नंबर','फोन'],
 'Alt Mobile':['alt mobile','alt. mobile','alt, mobile','altmobile','alternate mobile','alternate number','alternative mobile','alt phone','secondary mobile','whatsapp number','whatsapp no','दूसरा नंबर'],
 'Email':['email','e-mail','email address','mail','ईमेल'],
 'Address':['address','complete address','full address','shipping address','delivery address','customer address','पता','पूरा पता'],
 'Pincode':['pincode','pin code','pin-code','pin','pin no','pincod','postal code','zip','zip code','पिन','पिनकोड','पिन कोड'],
 'State':['state','province','राज्य'], 'District/City':['district/city','city/district','city','district','town','dist','distt','शहर','जिला'],
 'Post office':['post office','postoffice','p.o','po','डाकघर'], 'Landmark':['landmark','land mark','nearby','near','लैंडमार्क'],
 'Order ID':['order id','orderid','order no','order number','order #','ऑर्डर आईडी'],
 'Product':['product','product name','item','item name','console','उत्पाद'], 'Variant':['variant','storage','gb (if available)'], 'Quantity':['quantity','qty'],
 'Amount paid':['amount paid','paid amount','advance paid','amount','payment received'], 'Base Price':['base price','price'], 'Discount Applied':['discount applied','discount'],
 'Customer / Business Name':['customer / business name','business name'],'GB':['gb'],'Payment Status':['payment status'],'Courier Company':['courier company','courier'],
 'Distance':['distance'],'Prepaid Order ETA':['prepaid order eta'],'COD Order ETA':['cod order eta'],'Estimated Delivery':['estimated delivery'],'Rest on Delivery':['rest on delivery','rest amount on delivery'],'Date':['date']
};
const byKey=new Map(Object.entries(aliases).flatMap(([field,values])=>values.map(value=>[key(value),field])));
const labelAlternatives=Object.values(aliases).flat().sort((a,b)=>b.length-a.length).map(escape).join('|');
const labelPattern=new RegExp('(^|[\\s,;|])('+labelAlternatives+')\\.?\\s*(?:[:：=\\-]|(?=\\s*\\d)|\\s+-\\s+)\\s*','giu');
const stateList=['Andaman and Nicobar Islands','Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chandigarh','Chhattisgarh','Dadra and Nagar Haveli and Daman and Diu','Delhi','Goa','Gujarat','Haryana','Himachal Pradesh','Jammu and Kashmir','Jharkhand','Karnataka','Kerala','Ladakh','Lakshadweep','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Puducherry','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal'];
const stateAliases=[['Uttar Pradesh',['u.p.','u.p','up','उत्तर प्रदेश']],['Madhya Pradesh',['m.p.','m.p','mp','मध्य प्रदेश']],['Delhi',['new delhi','nct delhi','दिल्ली']],['Maharashtra',['महाराष्ट्र']],['Uttarakhand',['उत्तराखंड']],['West Bengal',['w.b.','wb']],['Tamil Nadu',['t.n.','tn']],['Jammu and Kashmir',['j&k','j & k']],['Odisha',['orissa']],['Punjab',['पंजाब']],['Rajasthan',['राजस्थान']],['Bihar',['बिहार']],['Karnataka',['कर्नाटक']]];
const stateEntries=[...stateList.map(s=>[s,s]),...stateAliases.flatMap(([s,values])=>values.map(a=>[a,s]))].sort((a,b)=>b[0].length-a[0].length);
const phonePattern=/(?<!\d)(?:(?:\+?91|0091)[\s().-]*)?(?:0[\s.-]*)?[6-9](?:[\s().-]*\d){9}(?!\d)/g;
function phones(text){return [...String(text).matchAll(phonePattern)].map(m=>({raw:m[0],number:m[0].replace(/\D/g,'').slice(-10),index:m.index}));}
function stateIn(text){for(const [alias,state]of stateEntries){const pattern=new RegExp('(^|[^\\p{L}])('+escape(alias)+')(?=$|[^\\p{L}])','iu'),m=String(text).match(pattern);if(m)return {state,raw:m[2],index:m.index+m[1].length};}return null;}
const addressHint=/\d|\b(?:road|rd|street|st|lane|house|flat|plot|sector|block|nagar|colony|society|village|vill|tehsil|taluka|near|opposite|opp|floor|building|apartment|ward|mohalla|gali|chowk|market|bazar|bazaar|post|school|office|complex|residency)\b|नगर|गली|रोड|मकान|गांव|गाँव|मोहल्ला|पास|कॉलोनी/i;
const greeting=/^(?:hi|hello|dear|thanks|thank you|sir|madam|details|customer details|shipping details|please|kindly|regards|send (?:it|to)|address details|delivery details|🙏|नमस्ते|धन्यवाद)[\s,.!:-]*$/i;
function nameCandidate(line){const value=clean(line).replace(/^(?:mr\.?|mrs\.?|ms\.?|shri|smt\.?|श्री)\s+/i,'');return value&&!/^(?:GAMES?\s*PLANET|prepaid order|cod order|shipping details|delivery address)$/i.test(value)&&!greeting.test(value)&&!addressHint.test(value)&&!/[\d@:=]/.test(value)&&/^[\p{L}\p{M} .'-]+$/u.test(value)&&value.split(/\s+/).length<=7?value:'';}
function parse(raw){
 const data={},issues=[],free=[],addressContinuation=[];const input=String(raw??'').replace(/\r\n?/g,'\n').replace(/[०-९]/g,c=>String(c.charCodeAt(0)-0x0966));
 let continuingAddress=false;
 for(const original of input.split('\n')){
  let line=clean(original.replace(/\*/g,'').replace(/^\s*[•▪▶✅📍📧📞☎️🟢🔴]+\s*/u,''));if(!line)continue;line=line.replace(/^(name|full name|customer name|address|email|state|city|district|dist\.?|distt\.?|post office|p\.o\.?|product|नाम|पता|शहर|जिला|राज्य)\s+(?![:：=])(.+)$/i,'$1: $2');
  const found=[...line.matchAll(labelPattern)];
  if(found.length){if(found[0].index>0){const prefix=clean(line.slice(0,found[0].index));if(prefix)free.push(prefix)}
   found.forEach((m,i)=>{const field=byKey.get(key(m[2])),value=clean(line.slice(m.index+m[0].length,found[i+1]?.index??line.length));if(field&&value){if(data[field]&&data[field]!==value&&field==='Address')data[field]+=', '+value;else if(!data[field])data[field]=value;else if(field==='Mobile'&&!data['Alt Mobile'])data['Alt Mobile']=value;else if(field==='Pincode')issues.push('Multiple PIN codes found; check the selected Pincode.');}continuingAddress=field==='Address';});
  }else{free.push(line);if(continuingAddress)addressContinuation.push(line);}
 }
 // Emails and phones are independent of line order and separators.
 const emails=[...input.matchAll(/[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9](?:[A-Z0-9.-]*[A-Z0-9])?\.[A-Z]{2,}/gi)].map(m=>m[0]);
 if(!data.Email&&emails.length)data.Email=emails[0];else if(data.Email)data.Email=emails.find(e=>data.Email.includes(e))||data.Email;
 const phoneSource=[data.Mobile,data['Alt Mobile'],data.Address,...free].filter(Boolean).join('\n');
 const allPhones=phones(phoneSource),unique=[...new Set(allPhones.map(p=>p.number))];
 const explicitMain=phones(data.Mobile||'').map(p=>p.number),explicitAlt=phones(data['Alt Mobile']||'').map(p=>p.number);
 data.Mobile=explicitMain[0]||unique.find(p=>p!==explicitAlt[0])||explicitAlt[0]||'';
 data['Alt Mobile']=explicitAlt.find(p=>p!==data.Mobile)||explicitMain.find(p=>p!==data.Mobile)||unique.find(p=>p!==data.Mobile)||'';
 if(unique.length>2)issues.push('More than two phone numbers found; check the selected Mobile and Alt Mobile.');
 const pinSource=[data.Pincode,data.Address,...free].filter(Boolean).join('\n');
 const withoutPhones=pinSource.replace(phonePattern,' ').replace(/[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,' ');
 const pins=[...new Set([...withoutPhones.matchAll(/(?<!\d)[1-9]\d{5}(?!\d)/g)].map(m=>m[0]))];
 const explicitPin=String(data.Pincode||'').match(/[1-9]\d{5}/)?.[0];data.Pincode=explicitPin||pins[0]||'';
 if(pins.length>1)issues.push('Multiple PIN codes found; check the selected Pincode.');
 const knownState=stateIn(data.State||'')||stateIn([data.Address,data['District/City'],...free].filter(Boolean).join('\n'));if(knownState)data.State=knownState.state;if(!data['District/City']&&/\bnew delhi\b/i.test(input))data['District/City']='New Delhi';
 const residual=free.map(text=>{let value=text.replace(phonePattern,' ').replace(/[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,' ');if(data.Pincode)value=value.replace(new RegExp('(?<!\\d)'+escape(data.Pincode)+'(?!\\d)','g'),' ');const state=stateIn(value);if(state)value=value.slice(0,state.index)+value.slice(state.index+state.raw.length);return clean(value).replace(/^[\s,;|:\-–]+|[\s,;|:\-–]+$/g,'')}).filter(v=>v&&!greeting.test(v)&&!/^\s*(?:India|भारत)\s*$/i.test(v));
 if(!data.Name){const candidates=residual.filter(v=>nameCandidate(v));const chosen=candidates.find(v=>v.split(/\s+/).length>=2)||candidates[0];if(chosen)data.Name=nameCandidate(chosen);}
 const addressParts=residual.filter(v=>v!==data.Name&&nameCandidate(v)!==data.Name);
 if(data.Address){const tail=addressContinuation.map(l=>clean(l)).filter(l=>!phones(l).length&&!l.includes('@')&&!stateIn(l)&&!/^\D*[1-9]\d{5}\D*$/.test(l)&&nameCandidate(l)!==data.Name);if(tail.length)data.Address=clean(data.Address+', '+tail.join(', '));}
 else data.Address=addressParts.join(', ');
 // City can be extracted from a final comma/hyphen segment; PIN lookup fills unknown locations later.
 if(!data['District/City']){const address=data.Address||'',tail=address.split(/[,;\n]|(?<=[\p{L}])\s*-\s*(?=[\p{L}])/u).map(clean).filter(Boolean);const last=tail.at(-1)||'';if(tail.length>1&&nameCandidate(last)&&!stateIn(last))data['District/City']=last;else if(addressParts.length>1){const lastLine=addressParts.at(-1);if(nameCandidate(lastLine)&&!stateIn(lastLine))data['District/City']=lastLine;}}
 if(data.GB&&!data.Variant)data.Variant=data.GB+'GB';
 if(data.Mobile===data['Alt Mobile'])data['Alt Mobile']='';
 for(const field of Object.keys(data))data[field]=clean(data[field]);
 if(!data.Product)data.Product='Game Product';
 if(!data['Amount paid'])data['Amount paid']='₹9999';
 const missing=['Name','Mobile','Address','Pincode'].filter(field=>!data[field]);
 return {data,missing,issues};
}
function format(data){return Object.entries(data).filter(([k,v])=>k!=='GB'&&v).map(([k,v])=>k+': '+v).join('\n');}
root.GPLabelParser={parse,format};
})(typeof window!=='undefined'?window:globalThis);
