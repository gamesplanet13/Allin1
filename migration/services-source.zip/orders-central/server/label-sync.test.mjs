import assert from 'node:assert/strict';import {readFileSync}from'node:fs';import vm from'node:vm';import {test}from'node:test';
test('8 manual boxes coexist with queue, persist, survive sync/errors and print together',async()=>{
 const els=new Map(),store=new Map();let orders=[{id:'order-a',revision:1,order_id:'GP-A',payload:{customer:{name:'Arun',mobile:'9876543210',address:'Test road'},order:{items:[{name:'Console',quantity:1}],advanceAmount:100,delivery:{}}}}],fail=false,printed=[];
 const simple=()=>({dataset:{},value:'',hidden:true,textContent:'',listeners:{},style:{},setAttribute(){},focus(){},addEventListener(t,f){this.listeners[t]=f},replaceChildren(){},append(){}});
 const el=id=>{if(!els.has(id))els.set(id,simple());return els.get(id)};
 for(const id of ['labelContainer','manualLabelContainer'])Object.assign(el(id),{children:[],append(child){if(child.parent)child.parent.children.splice(child.parent.children.indexOf(child),1);this.children.push(child);child.parent=this},before(){},get lastElementChild(){return this.children.at(-1)}});
 for(const id of ['labelContainer','manualLabelContainer'])Object.defineProperty(el(id),'lastElementChild',{get(){return this.children.at(-1)}});
 const wrappers=()=>[...el('manualLabelContainer').children,...el('labelContainer').children];
 const select=selector=>selector==='[data-order-id]'?wrappers().filter(e=>e.dataset.orderId):selector.includes(':not(')?wrappers().filter(e=>!e.dataset.orderId).map(e=>e.ta):wrappers().map(e=>e.ta);
 const queueAdd=()=>{const node=simple();node.ta=simple();node.actions=simple();node.querySelector=s=>s==='.label-actions'?node.actions:node.ta;node.remove=()=>node.parent.children.splice(node.parent.children.indexOf(node),1);el('labelContainer').append(node)};
 const window={addNewTextarea:queueAdd,onload(){},generatePDF:async()=>{printed=wrappers().map(e=>e.ta.value).filter(Boolean);return true},clearLabel(){},deleteLabel(){},addEventListener(){}};
 const context=vm.createContext({window,document:{getElementById:el,createElement:()=>simple(),querySelectorAll:select,hidden:false},localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)},fetch:async()=>Response.json(fail?{error:'Please login'}:{orders},{status:fail?401:200}),Response,AbortController,setTimeout,clearTimeout,setInterval(){},updateLabelCount(){}});
 vm.runInContext(readFileSync(new URL('./label-sync.js',import.meta.url),'utf8'),context);await window.onload();
 assert.equal(el('manualLabelContainer').children.length,8);assert.equal(el('labelContainer').children.length,1);assert.match(el('labelContainer').children[0].ta.value,/Name: Arun\n/);assert(!el('labelContainer').children[0].ta.value.includes('\\n'));
 const draft='Name: Manual Buyer\nMobile: 9000000000';el('manualLabelContainer').children[0].ta.value=draft;el('manualLabelContainer').listeners.input();assert.equal(JSON.parse(store.get('gp_label_manual_drafts'))[0],draft);
 orders=[];await el('syncQueue').onclick();assert.equal(el('labelContainer').children.length,0);assert.equal(el('manualLabelContainer').children[0].ta.value,draft);
 window.addNewTextarea();assert.equal(el('manualLabelContainer').children.length,9);fail=true;await el('syncQueue').onclick();assert.equal(el('manualLabelContainer').children[0].ta.value,draft);assert.equal(el('connectOwner').hidden,false);
 await window.generatePDF('save');assert(printed.includes(draft));
});
