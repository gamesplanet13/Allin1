import {buildOrderMessage} from './order-template.js';
export const mobile10=value=>String(value??'').replace(/\D/g,'').replace(/^91(?=\d{10}$)/,'').replace(/^0(?=\d{10}$)/,'');
export function paymentMode(record){const value=String(record.payload?.order?.paymentMode||'').toLowerCase();return value==='cod'?'cod':value==='prepaid'?'prepaid':'unknown'}
const cash=value=>value===null||value===undefined||value===''?'Not supplied':'₹'+Number(value).toLocaleString('en-IN',{maximumFractionDigits:2});
const line=value=>String(value??'').replace(/[\r\n]+/g,' ').trim();
export function buildMessage(record,type){
 const p=record.payload||{},c=p.customer||{},o=p.order||{},d=o.delivery||{},mode=paymentMode(record),label=mode==='cod'?'COD':mode==='prepaid'?'PREPAID':'Not supplied — please confirm';
 if(['prepaid','cod'].includes(type)&&mode!==type)throw Error('This order uses '+label+'. Save a payment mode change in Open / edit before preparing a different payment message.');
 if(['prepaid','cod'].includes(type))return buildOrderMessage(record,type);
 const products=(o.items||[]).map(i=>line(i.name||i.product)+(i.variant?' ('+line(i.variant)+')':'')+' × '+(i.quantity??1)).join('\n');
 const address=[c.house,c.address,c.landmark,c.city,c.state,c.pincode].filter(Boolean).map(line).join(', ');
 const eta=mode==='cod'?(d.etaCod||d.codEta||d.eta):(d.etaPrepaid||d.eta);
 const delivery=[eta?'⏳ Estimated Delivery: '+line(eta):'',d.estimatedDelivery?'📅 Delivery window: '+line(d.estimatedDelivery):''].filter(Boolean).join('\n');
 const verified=Boolean(record.payment_verified),advance=o.advanceAmount;
 const remaining=o.restAmount??(o.grandTotal!=null&&advance!=null?Math.max(0,Number(o.grandTotal)-Number(advance)):null);
 const totals=['Final Total: '+cash(o.grandTotal),verified?'Amount Paid / Verified: '+cash(advance):'Advance / Payment to confirm: '+cash(advance),mode==='cod'?'Rest on Delivery: '+cash(remaining):''].filter(Boolean).join('\n');
 const intro='🌟 *GAMES PLANET*\n🙏 Hello '+line(c.name||'Customer')+' ji,';
 const details='Order ID: '+line(record.order_id)+'\nPayment Mode: '+label+'\n📦 Product: '+products+'\nMobile: '+mobile10(c.mobile)+'\n📍 Address: '+address;
 if(type==='thanks')return intro+' thank you for your order.\n'+details+'\n'+totals+(delivery?'\n'+delivery:'')+'\n'+(record.status==='successful'||record.status==='dispatched'?'We will share tracking after dispatch. Parcel photo and tracking number are available on request.':'We have received your order details. Payment and dispatch confirmation will follow after review.')+'\n💚 Team GAMES PLANET';
 if(type==='abandoned')return intro+'\n\n📝 Incomplete Order Details:\n'+details+'\n'+totals+(delivery?'\n'+delivery:'')+'\n\n'+(verified?'Your payment is verified. Please reply here if you need help with this order.':mode==='cod'?'Please confirm your COD order and the required advance on WhatsApp.':mode==='prepaid'?'Complete payment and share confirmation here to confirm your prepaid order.':'Please confirm your preferred payment mode and complete the order on WhatsApp.')+'\n💚 Team GAMES PLANET';
 return (mode==='cod'?'🔴 COD Order':'🟢 Prepaid Order')+' — *GAMES PLANET*\n'+details+'\n'+totals+(delivery?'\n'+delivery:'')+'\nPayment Status: '+(verified?'Verified':'Pending verification');
}
export function whatsappURL(record,message,target='customer'){if(!['customer','own'].includes(target))throw Error('Invalid WhatsApp destination');const number=target==='own'?'7983624797':mobile10(record.payload?.customer?.mobile);if(!/^\d{10}$/.test(number))throw Error('A valid 10-digit customer mobile is required. Correct it in Open / edit.');return 'https://wa.me/91'+number+'?text='+encodeURIComponent(message)}
