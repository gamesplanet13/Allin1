(function(root){'use strict';
const postal=new Map();
async function prepare(text){const result=root.GPLabelParser.parse(text),data=result.data;if(data.Pincode&&(!data.State||!data['District/City'])&&root.GPPostal){try{if(!postal.has(data.Pincode))postal.set(data.Pincode,Promise.race([root.GPPostal.lookup(data.Pincode),new Promise((_,reject)=>setTimeout(()=>reject(Error('PIN lookup timed out')),3500))]));const location=await postal.get(data.Pincode);if(location){if(!data.State)data.State=location.state;if(!data['District/City'])data['District/City']=location.city;}else result.issues.push('PIN was not found in the postal data; check city and state.');}catch{postal.delete(data.Pincode);result.issues.push('City/state lookup is unavailable. Pasted details have been kept.');}}return result;}
// Detection is used by PDF/Print only; no detected-details preview is rendered.
function show(){}
root.GPLabelManual={prepare,show};
})(window);
