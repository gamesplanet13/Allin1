// Full order handoff, matching the checkout template. Read saved values, never reprice an order.
const text=v=>String(v??'').replace(/[\r\n]+/g,' ').trim();
const number=v=>{if(v===null||v===undefined||v==='')return null;const s=String(v).replace(/[₹,]/g,'').replace(/\s*\([^)]*\)\s*$/,'').trim();return s&&Number.isFinite(Number(s))?Number(s):null};
const cash=v=>number(v)===null?'Not supplied':'₹'+number(v).toLocaleString('en-IN',{maximumFractionDigits:2});
const phone=v=>text(v).replace(/\D/g,'').replace(/^91(?=\d{10}$)/,'').replace(/^0(?=\d{10}$)/,'');
const key=v=>text(v).toLowerCase().replace(/[^a-z0-9]/g,'');
const first=(...values)=>values.find(v=>v!==undefined&&v!==null&&v!=='');
const plus=(a,b)=>number(a)===null||number(b)===null?null:number(a)+number(b);
const multiply=(a,b)=>number(a)===null||number(b)===null?null:number(a)*number(b);
function originalFields(message){const result={};for(const line of String(message||'').split('\n')){const m=line.replace(/\*/g,'').replace(/^[^a-z0-9]+/i,'').match(/^([^:]{1,80}):\s*(.*)$/);if(m&&!Object.hasOwn(result,key(m[1])))result[key(m[1])]=m[2].trim()}return result}
function value(v,suffix=''){return v===undefined||v===null||v===''?'Not supplied':text(v)+suffix}
function dimensions(v){if(Array.isArray(v))return v.length?v.join(' × ')+' cm':'Not supplied';return value(v)}
export function buildOrderMessage(record,mode){
 const p=record.payload||{},c=p.customer||{},o=p.order||{},d=o.delivery||{},old=originalFields(p.message),get=(v,k)=>first(v,old[key(k)]),cod=mode==='cod',items=o.items||[];
 const named=i=>text(i.name||i.product||'Product')+(i.variant&&!text(i.name).includes(text(i.variant))?' — '+text(i.variant):'');
 const qty=i=>first(i.quantity,1),itemTotals=items.map(i=>first(i.lineTotal,multiply(i.unitPrice,qty(i))));
 const productTotal=get(first(o.productTotal,itemTotals.length&&itemTotals.every(v=>number(v)!==null)?itemTotals.reduce((s,v)=>s+number(v),0):undefined),'Products + Add-ons');
 const courier=get(o.courierCharge,'Courier Charges'),paid=get(o.advanceAmount,'Amount Paid'),grand=get(o.grandTotal,'Final Order Total');
 const remaining=first(o.restAmount,number(grand)!==null&&number(paid)!==null?Math.max(0,number(grand)-number(paid)):undefined,old[cod?'restondelivery':'remainingamount']);
 const gst=o.gstInvoiceIncluded??(/Included/i.test(old.gstinvoice||'')&&!/Excluded/i.test(old.gstinvoice||'')?true:/Excluded/i.test(old.gstinvoice||'')?false:null);
 const courierName=first(record.courier,o.courier,old.couriercompany),pickup=o.fulfillment==='pickup';
 const eta=cod?first(d.etaCod,d.codEta,d.eta,old.codordereta):first(d.etaPrepaid,d.eta,old.prepaidordereta);
 const date=cod?first(d.estimatedDeliveryCod,d.estimatedDelivery,old.estimateddelivery):first(d.estimatedDelivery,old.estimateddelivery);
 const originalItems=String(p.message||'').split(/\n\s*\d+\.\s*(?:PRODUCT|ADD-ON)\s*\n/i).slice(1).map(originalFields);
 const itemLines=items.flatMap((i,n)=>{const fallback=originalItems.find(x=>text(x.namevariant)===named(i));const field=(v,k)=>first(v,fallback?.[key(k)]);return [
  `${n+1}. ${n===0?'PRODUCT':'ADD-ON'}`,`Name / Variant: ${named(i)}`,`Quantity: ${value(qty(i))}`,
  `Unit Price: ${cash(first(i.unitPrice,number(i.lineTotal)!==null&&number(qty(i))>0?number(i.lineTotal)/number(qty(i)):undefined))}`,
  `Line Total: ${cash(itemTotals[n])}`,`Unit Weight: ${value(field(i.unitWeight,'Unit Weight'),i.unitWeight!=null?'g':'')}`,
  `Total Weight: ${value(field(first(i.lineWeight,multiply(i.unitWeight,qty(i))),'Total Weight'),first(i.lineWeight,multiply(i.unitWeight,qty(i)))!=null?'g':'')}`,
  `Approx. Unit Dimensions: ${i.shippingIgnoreDimensions&&!i.dimensions?.length?'Mounted inside Full Body Arcade — no separate TV carton':dimensions(field(i.dimensions?.length?i.dimensions:undefined,'Approx. Unit Dimensions'))}`,
  ...(Array.isArray(i.components)?i.components.map(x=>`Component: ${text(x.name)} x${value(x.quantity)}`):[]),'────────────────────',''];});
 const paymentStatus=!record.payment_verified?'PAYMENT VERIFICATION PENDING':number(remaining)===0?'FULLY PAID':number(paid)>0?(cod?'PARTIALLY PAID — COD':'PARTIALLY PAID'):'PAYMENT VERIFIED';
 const lines=[cod?'🔴 COD Order on WhatsApp':'🟢 Prepaid Order on WhatsApp','',
  `Order ID: ${text(record.order_id)}`,`Name: ${text(c.name)}`,`Mobile: ${phone(c.mobile)}`,`Alt Mobile: ${phone(c.altMobile)}`,`Email: ${text(c.email)}`,
  `Address: ${[c.house,c.address].filter(Boolean).map(text).join(', ')}`,`Landmark: ${text(c.landmark)}`,`Pincode: ${text(c.pincode)}`,`State: ${text(c.state)}`,
  `District/City: ${text(c.city)}`,`Post office: ${text(c.postoffice)}`,'',
  `Product: ${items.map(i=>named(i)+' x'+qty(i)).join(' + ')}`,`Variant: ${items.map(i=>text(i.variant)).filter(Boolean).join(' + ')||old.variant||'As selected'}`,
  `Base Price: ${cash(get(o.basePriceDisplay,'Base Price'))}`,`Courier Company: ${value(courierName)}`,`GST Invoice: ${gst===true?'Included (18%)':gst===false?'Excluded':'Not supplied'}`,
  `Amount Paid: ${cash(paid)}`,...(cod?[`Rest on Delivery: ${cash(remaining)}`]:[]),'',
  ...(pickup?['Delivery: Shop Pickup — Courier ₹0']:[`📏 Distance: ${value(get(d.distance,'Distance'))}`,`⏳ ${cod?'COD':'Prepaid'} Order ETA: ${value(eta)}`,`📅 Estimated Delivery: ${value(date)}`]),'',
  '━━━━━━━━━━━━━━━━━━━━','🧾 COMPLETE ORDER BREAKDOWN','━━━━━━━━━━━━━━━━━━━━','',...itemLines,
  '📦 WEIGHT & DIMENSION BREAKDOWN',`Products Weight: ${value(get(o.totalWeight,'Products Weight'),o.totalWeight!=null?'g':'')}`,
  `Packaging Weight: ${value(get(o.packingWeight,'Packaging Weight'),o.packingWeight!=null?'g':'')}`,`Packed Weight: ${value(get(o.packedWeight,'Packed Weight'),o.packedWeight!=null?'g':'')}`,
  `Recommended Box: ${dimensions(get(o.boxDimensions?.length?o.boxDimensions:undefined,'Recommended Box'))}`,
  `Actual Weight: ${value(o.actualKg!=null?Number(o.actualKg).toFixed(2)+'kg':old.actualweight)}`,
  `Volumetric Weight: ${o.usesVolumetric===false?'Not applicable for '+value(courierName):value(o.volumetricKg!=null?Number(o.volumetricKg).toFixed(2)+'kg':old.volumetricweight)}`,
  `Chargeable Weight: ${value(o.chargeableKg!=null?Number(o.chargeableKg).toFixed(2)+'kg':old.chargeableweight)}`,'',
  '━━━━━━━━━━━━━━━━━━━━','💰 PAYMENT BREAKDOWN','━━━━━━━━━━━━━━━━━━━━','',
  `Total Products: ${items.reduce((s,i)=>s+(number(qty(i))||0),0)}`,`Products + Add-ons: ${cash(productTotal)}`,`Courier Charges: ${cash(courier)}`,
  `Products + Courier: ${cash(first(plus(productTotal,courier),old.productscourier))}`,
  ...(o.discountApplied!=null||old.discountapplied||old.discount?[`Discount Applied: ${cash(first(o.discountApplied,old.discountapplied,old.discount))}`]:[]),
  ...(o.discountCode?[`Discount Code: ${text(o.discountCode)}`]:[]),
  `GST Invoice (18%): ${gst===false?'₹0 (Excluded)':cash(get(o.productGst,'GST Invoice (18%)'))}`,
  ...(gst||c.businessName||c.gstin||c.billingAddress?[`Seller GSTIN: ${old.sellergstin||'09DIDPS5066Q1ZB'}`,`Customer / Business Name: ${text(c.businessName)}`,`Customer GSTIN: ${text(c.gstin)}`,`GST Billing Address: ${text(c.billingAddress)}`]:[]),
  `Total Before VAS: ${cash(get(o.totalBeforeVas,'Total Before VAS'))}`,`VAS (2%): ${o.vasApplies===false?'₹0 (Not Applicable)':cash(get(o.vasCharge,'VAS (2%)'))}`,'',
  `Final Order Total: ${cash(grand)}`,`Amount Paid: ${cash(paid)}`,`${cod?'Rest on Delivery':'Remaining Amount'}: ${cash(remaining)}`,
  `Payment Status: ${paymentStatus}`,`Payment Method: ${cod?'Cash on Delivery':'Prepaid'}`];
 return lines.join('\n');
}
