export const COURIERS=['Trackon.in','ShreeMaruti.com','DTDC.in','Blue Dart','Ecom','Delhivery','India Post','Other'];
export function trackingURL(courier,awb,custom=''){
 if(courier==='Other'){if(!custom)return '';const u=new URL(custom);if(u.protocol!=='https:'||u.username||u.password)throw Error('Tracking URL must use HTTPS');return u.href;}
 const urls={'Trackon.in':'https://trackon.in/courier-tracking','ShreeMaruti.com':'https://shreemaruti.com/track-shipment/','DTDC.in':'https://www.dtdc.com/track-your-shipment/','Blue Dart':'https://www.bluedart.com/tracking','Ecom':'https://www.ecomexpress.in/tracking/?awb_field='+encodeURIComponent(awb),'Delhivery':'https://www.delhivery.com/tracking','India Post':'https://www.indiapost.gov.in/_layouts/15/dop.portal.tracking/trackconsignment.aspx'};
 return urls[courier]||'';
}
export function shipmentChange(row,b,now=new Date()){
 if(!['successful','dispatched','delivered'].includes(row.status))throw Error('Accept this order before adding dispatch details.');
 if(!['save','dispatch','delivered'].includes(b.action))throw Error('Choose Save, Mark dispatched or Mark delivered.');
 if(b.action==='dispatch'&&!['successful','dispatched'].includes(row.status))throw Error('This order is already delivered.');
 if(b.action==='delivered'&&!['dispatched','delivered'].includes(row.status))throw Error('Mark this order dispatched before marking delivered.');
 const courier=String(b.courier??row.courier??'').trim(),awb=String(b.trackingNumber??row.tracking_number??'').trim();
 if(!COURIERS.includes(courier))throw Error('Choose a courier company.');
 if(!/^[a-zA-Z0-9][a-zA-Z0-9 /._-]{1,99}$/.test(awb))throw Error('Enter a valid AWB / tracking number (2–100 letters or digits).');
 const day=String(b.dispatchDate??row.dispatch_date??'').trim()||new Date(now.getTime()+19800000).toISOString().slice(0,10);
 if(!/^\d{4}-\d{2}-\d{2}$/.test(day)||new Date(day).toISOString().slice(0,10)!==day)throw Error('Enter a valid dispatch date.');
 return {status:b.action==='dispatch'?'dispatched':b.action==='delivered'?'delivered':row.status,courier,tracking_number:awb,tracking_url:trackingURL(courier,awb,String(b.trackingUrl??row.tracking_url??'').trim()),dispatch_date:day,delivered_at:b.action==='delivered'?(row.delivered_at||now.toISOString()):(row.delivered_at||'')};
}
export async function readParcelImage(req,max=2*1024*1024){
 const error=message=>{throw Object.assign(Error(message),{status:400})};
 const declared=Number(req.headers.get('Content-Length'));if(declared>max)throw Object.assign(Error('Photo must be smaller than 2 MB.'),{status:413});
 const reader=req.body?.getReader();if(!reader)error('Choose a parcel photo.');const parts=[];let size=0;while(true){const {value,done}=await reader.read();if(done)break;size+=value.byteLength;if(size>max){await reader.cancel();throw Object.assign(Error('Photo must be smaller than 2 MB.'),{status:413})}parts.push(value)}
 const bytes=new Uint8Array(size);let at=0;for(const p of parts){bytes.set(p,at);at+=p.length}
 let mime;if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)mime='image/jpeg';else if([137,80,78,71,13,10,26,10].every((v,i)=>bytes[i]===v))mime='image/png';else if(new TextDecoder().decode(bytes.slice(0,4))==='RIFF'&&new TextDecoder().decode(bytes.slice(8,12))==='WEBP')mime='image/webp';
 if(!mime||size<12)error('Use a JPEG, PNG or WebP parcel photo.');return {bytes,mime};
}
