import orderService from "../server/orders.mjs";
import { DASHBOARD_HTML, LABEL_HTML } from "../server/pages.mjs";
import labelParser from "../server/label-parser.js?raw";
import labelManual from "../server/label-manual.js?raw";
import labelSync from "../server/label-sync.js?raw";
import dashboardScript from "../server/dashboard.js?raw";
import orderMessages from "../server/order-messages.js?raw";
import orderTemplate from "../server/order-template.js?raw";
import shippingScript from "../server/shipping.js?raw";
import shipmentUIScript from "../server/shipment-ui.js?raw";
import orderStatusScript from "../server/order-status.js?raw";
import handler from "vinext/server/fetch-handler";
import { runWithConnectorBinding } from "../lib/connector-context";
import type { ConnectorBinding } from "../lib/connector-contract.mjs";

const worker = {
  fetch(request: Request, env: Cloudflare.Env, ctx: ExecutionContext<{ CONNECTORS?: ConnectorBinding }>) {
    const url=new URL(request.url);
    if(url.pathname==='/label-sync.js')return new Response(labelSync,{headers:{'Content-Type':'text/javascript; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
    const scripts: Record<string,string>={'/dashboard.js':dashboardScript,'/shipping.js':shippingScript,'/shipment-ui.js':shipmentUIScript,'/order-messages.js':orderMessages,'/order-template.js':orderTemplate,'/order-status.js':orderStatusScript,'/label-parser.js':labelParser,'/label-manual.js':labelManual};
    if(scripts[url.pathname])return new Response(scripts[url.pathname],{headers:{'Content-Type':'text/javascript; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
    if(url.pathname.startsWith('/api/')){url.pathname=url.pathname.slice(4);return orderService.fetch(new Request(url,request),env);}
    if(url.pathname==='/'||url.pathname==='/labels')return new Response(url.pathname==='/labels'?LABEL_HTML:DASHBOARD_HTML,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Robots-Tag':'noindex, nofollow, noarchive, nosnippet','X-Frame-Options':'DENY','Content-Security-Policy':"frame-ancestors 'none'; base-uri 'self'; object-src 'none'"}});
    let binding = ctx.props?.CONNECTORS;
    // Local preview emulates the same request-scoped capability. This branch and
    // the auxiliary service binding are absent from production builds.
    if (import.meta.env.DEV && !binding && env.CONNECTORS) {
      const preview = env.CONNECTORS;
      const expiresAt = Date.now() + 60_000;
      binding = {
        async getContext() {
          if (Date.now() >= expiresAt) return { status: "request_context_expired" };
          return preview.getContext?.() ?? { status: "binding_unavailable" };
        },
        async invoke(connectorId, actionName, args) {
          if (Date.now() >= expiresAt) {
            return { status: "request_context_expired", message: "This request has expired. Please try again." };
          }
          return preview.invoke(connectorId, actionName, args);
        },
      };
    }
    return runWithConnectorBinding(binding, () => handler.fetch(request, env, ctx));
  },
};

export default worker;
