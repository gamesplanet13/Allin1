import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "GAMES PLANET — Orders & Labels",
  description: "Games Planet owner order dashboard and persistent prepaid label queue.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
