ALTER TABLE `orders` ADD `parcel_photo_key` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `parcel_photo_mime` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `photo_updated_at` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `delivered_at` text DEFAULT '' NOT NULL;