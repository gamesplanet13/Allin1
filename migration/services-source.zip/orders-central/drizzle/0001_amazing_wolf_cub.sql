CREATE TABLE `customer_blocks` (
	`identity` text PRIMARY KEY NOT NULL,
	`customer_ref` text NOT NULL,
	`blocked` integer DEFAULT 1 NOT NULL,
	`reason` text DEFAULT '' NOT NULL,
	`changed_at` text NOT NULL,
	`actor` text NOT NULL
);
